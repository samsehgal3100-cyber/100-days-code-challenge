# Daily-Challenge-100-Days-of-Code-UPES-
 🚀 100 Days of Code in C

This repository contains my journey of *100 Days of Code* where I solve problems daily using *C language*.  
The goal of this challenge is to improve my *problem-solving skills, logic building, and consistency*.
---

## 📌 Questions Source
All the problems I solve are from the following resource(s):  
🔗  https://maitysoumik.github.io/basic-coding-with-c/ 


---

## 🏆 Goals
- Practice C language consistently for 100 days  
- Strengthen programming fundamentals  
- Solve real-world coding problems  
- Build a daily coding habit  

---

## 📅 Day-wise Progress

| Day | Problem Link | Solution |
|-----|--------------|----------|
| 1   | [Question 1] | [Solution] |
| ... | ...          | ...      |


