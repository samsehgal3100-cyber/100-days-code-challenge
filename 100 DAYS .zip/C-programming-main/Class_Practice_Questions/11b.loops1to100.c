// wap to print the number between 1 to 100 using: a. for loop b.while loop c.do while loop
#include<stdio.h>

int main()
{
    int i;
    for(i=1;i<=100;i++)
    {
        printf("%d\n",i);
    }
    return 0;
}
