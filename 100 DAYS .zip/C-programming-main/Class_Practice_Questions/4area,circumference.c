#include<stdio.h>

int main()
{
    float r,a,c;
    printf("Enter the radius=");
    scanf("%f",&r);
    printf("area of circle=%f",3.14*r*r);
    printf("Circumference=%f",2*3.14);
}