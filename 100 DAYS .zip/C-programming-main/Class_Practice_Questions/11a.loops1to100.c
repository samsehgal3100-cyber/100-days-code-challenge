// wap to print the number between 1 to 100 using: a. for loop b.while loop c.do while loop

#include<stdio.h>

int main()
{
    int i=1;
    while(i<=100)
    {
        printf("%d\n",i);
        i++;
    }
    return 0;
    }