#include<stdio.h>

int main()
{
    int a=5;
    float b=4.5;
    char ch='A';


    printf("integer variable %d",a);
    printf("character variable %c",ch);
    printf("Floaat variable  %f",b);
}